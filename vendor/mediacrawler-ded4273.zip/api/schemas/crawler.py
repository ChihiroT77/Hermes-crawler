# -*- coding: utf-8 -*-
# Copyright (c) 2025 relakkes@gmail.com
#
# This file is part of MediaCrawler project.
# Repository: https://github.com/NanmiCoder/MediaCrawler/blob/main/api/schemas/crawler.py
# GitHub: https://github.com/NanmiCoder
# Licensed under NON-COMMERCIAL LEARNING LICENSE 1.1
#
# 声明：本代码仅供学习和研究目的使用。使用者应遵守以下原则：
# 1. 不得用于任何商业用途。
# 2. 使用时应遵守目标平台的使用条款和robots.txt规则。
# 3. 不得进行大规模爬取或对平台造成运营干扰。
# 4. 应合理控制请求频率，避免给目标平台带来不必要的负担。
# 5. 不得用于任何非法或不当的用途。
#
# 详细许可条款请参阅项目根目录下的LICENSE文件。
# 使用本代码即表示您同意遵守上述原则和LICENSE中的所有条款。

from enum import Enum
from typing import Any, Dict, Optional, Literal
from pydantic import BaseModel, Field


# Upper bound accepted by the WebUI for "how many notes / comments".
# The WebUI exposes a free-form input so the crawler can be told to keep going
# until the platform runs out of results.
MAX_API_LIMIT_COUNT = 1000000


class PlatformEnum(str, Enum):
    """Supported media platforms"""
    XHS = "xhs"
    DOUYIN = "dy"
    KUAISHOU = "ks"
    BILIBILI = "bili"
    WEIBO = "wb"
    TIEBA = "tieba"
    ZHIHU = "zhihu"


class LoginTypeEnum(str, Enum):
    """Login method"""
    QRCODE = "qrcode"
    PHONE = "phone"
    COOKIE = "cookie"


class CrawlerTypeEnum(str, Enum):
    """Crawler type"""
    SEARCH = "search"
    DETAIL = "detail"
    CREATOR = "creator"


class SaveDataOptionEnum(str, Enum):
    """Data save option"""
    CSV = "csv"
    DB = "db"
    JSON = "json"
    JSONL = "jsonl"
    SQLITE = "sqlite"
    MONGODB = "mongodb"
    EXCEL = "excel"
    POSTGRES = "postgres"


class CrawlerStartRequest(BaseModel):
    """Crawler start request"""
    platform: PlatformEnum
    login_type: LoginTypeEnum = LoginTypeEnum.QRCODE
    crawler_type: CrawlerTypeEnum = CrawlerTypeEnum.SEARCH
    keywords: str = ""  # Keywords for search mode
    specified_ids: str = ""  # Post/video ID list for detail mode, comma-separated
    creator_ids: str = ""  # Creator ID list for creator mode, comma-separated
    start_page: int = 1
    enable_comments: bool = True
    enable_sub_comments: bool = False
    enable_media: bool = False
    # Generate a comment word cloud after crawling (requires comments + json/jsonl save option)
    enable_wordcloud: bool = False
    # Additionally export an Excel workbook (multi-sheet) after crawling while
    # keeping the primary save option (json/jsonl), so the word cloud still works.
    enable_excel_export: bool = False
    save_option: SaveDataOptionEnum = SaveDataOptionEnum.JSONL
    cookies: str = ""
    headless: bool = False
    max_notes_count: Optional[int] = Field(default=None, ge=1, le=MAX_API_LIMIT_COUNT)
    max_comments_count: Optional[int] = Field(default=None, ge=1, le=MAX_API_LIMIT_COUNT)
    # Concurrency of in-flight requests (1 = one at a time, safest)
    max_concurrency: Optional[int] = Field(default=None, ge=1, le=32)
    # Custom data directory; empty means the default <project>/data
    save_data_path: str = ""
    # ---- IP proxy ----
    enable_ip_proxy: bool = False
    ip_proxy_pool_count: Optional[int] = Field(default=None, ge=1, le=100)
    ip_proxy_provider_name: str = ""
    static_proxy_url: str = ""
    # Third-party proxy credentials, passed to the crawler process as
    # environment variables (see proxy/providers/*.py). Only known names are
    # forwarded; the allowlist lives in api/services/crawler_manager.py.
    ip_proxy_credentials: Dict[str, str] = Field(default_factory=dict)
    # Everything else the WebUI controls and that has no dedicated flag:
    # {"config": {...}, "db": {...}} -> applied to the config module by
    # cmd_arg.arg._apply_config_overrides (whitelisted keys only).
    config_overrides: Dict[str, Any] = Field(default_factory=dict)


class CrawlerStatusResponse(BaseModel):
    """Crawler status response"""
    status: Literal["idle", "running", "stopping", "error"]
    platform: Optional[str] = None
    crawler_type: Optional[str] = None
    started_at: Optional[str] = None
    error_message: Optional[str] = None


class LogEntry(BaseModel):
    """Log entry"""
    id: int
    timestamp: str
    level: Literal["info", "warning", "error", "success", "debug"]
    message: str


class DataFileInfo(BaseModel):
    """Data file information"""
    name: str
    path: str
    size: int
    modified_at: str
    record_count: Optional[int] = None
