/**
 * Upper bound accepted by the backend
 * (api/schemas/crawler.py -> MAX_API_LIMIT_COUNT).
 */
export const MAX_CRAWL_COUNT = 1000000

export interface CrawlerConfig {
  platform: string
  login_type: string
  crawler_type: string
  keywords: string
  specified_ids: string  // 详情模式下的帖子/视频ID
  creator_ids: string    // 创作者模式下的创作者ID
  start_page: number
  enable_comments: boolean
  enable_sub_comments: boolean
  enable_media: boolean  // 是否下载媒体（封面/视频/图文图片），支持 xhs/dy/ks/bili/wb
  enable_wordcloud: boolean  // 爬取结束后生成评论词云图（需评论 + JSON/JSONL 保存格式）
  enable_excel_export: boolean  // 主格式之外再额外导出一份 Excel（多 sheet）
  save_option: string
  cookies: string
  headless: boolean

  // ---- 抓取规模（每个关键词单独计算）----
  max_notes_count: number      // 每个关键词最多抓多少条笔记/视频
  max_comments_count: number   // 每条笔记最多抓多少条一级评论

  // ---- 速度与稳定性 ----
  max_concurrency: number      // 并发数
  sleep_sec: number            // 每页之间的间隔秒数
  download_live_photo: boolean // 下载实况照片随附视频（需开「下载媒体」）

  // ---- 存储 ----
  save_data_path: string       // 自定义数据目录，留空 = 项目 data 目录
  db_host: string              // 数据库连接（仅保存格式为数据库时生效）
  db_port: number
  db_user: string
  db_password: string
  db_name: string

  // ---- IP 代理 ----
  enable_ip_proxy: boolean
  ip_proxy_pool_count: number
  ip_proxy_provider_name: string  // kuaidaili | wandouhttp | static
  static_proxy_url: string
  kdl_secret_id: string        // 快代理 4 个参数（服务商后台可见）
  kdl_signature: string
  kdl_user_name: string
  kdl_user_pwd: string
  wandou_app_key: string       // 豌豆HTTP 的 app_key

  // ---- 平台专属 ----
  xhs_sort: string             // xhs: general | popularity_descending | time_descending
  dy_publish_time: number      // dy: 0 不限 / 1 一天内 / 7 一周内 / 180 半年内（必须和爬虫枚举一致）
  bili_search_mode: string     // bili: normal | all_in_time_range | daily_limit_in_time_range
  bili_start_day: string       // bili: 时间区间模式下的开始日期 YYYY-MM-DD
  bili_end_day: string         // bili: 时间区间模式下的结束日期 YYYY-MM-DD
  bili_qn: number              // bili: 清晰度 16/32/64/80/112/116/120
  bili_max_notes_per_day: number  // bili: 时间区间模式下每天的上限（两种区间模式都生效）
  weibo_full_text: boolean     // wb: 抓正文全文（关闭则抓摘要）

  // ---- 词云调优 ----
  custom_words: string         // 自定义词，格式「词:分组」，逗号分隔
  stop_words_file: string      // 停用词表路径
  font_path: string            // 中文字体路径
}

export interface CrawlerStatus {
  status: 'idle' | 'running' | 'stopping' | 'error'
  platform: string | null
  crawler_type: string | null
  started_at: string | null
  error_message: string | null
}

export interface LogEntry {
  id: number
  timestamp: string
  level: 'info' | 'warning' | 'error' | 'success' | 'debug'
  message: string
}

export interface DataFile {
  name: string
  path: string
  size: number
  modified_at: number
  record_count: number | null
  type: string
}

export interface Platform {
  value: string
  label: string
  icon: string
}

export interface ConfigOption {
  value: string
  label: string
}
